import { readFile } from "node:fs/promises";
import { resolveBrand } from "../brand/i18n.ts";
import type { BrandtreeProject } from "../core/project-tree.ts";
import type { RuntimeOgAssets } from "../core/types.ts";

/** Bundle local assets before Astro changes working directories to prerender. */
export const buildOgAssets = async ({
  config,
  context,
}: BrandtreeProject): Promise<{
  assets: RuntimeOgAssets;
  warnings: string[];
}> => {
  const assets: RuntimeOgAssets = { logos: {}, fontData: {} };
  const warnings: string[] = [];
  const og = config.seo.og;
  if (!og.enabled) return { assets, warnings };
  const references = context.assetReferences;

  const locales = new Set([
    ...(config.i18n?.locales.map(({ code }) => code) ?? ["en"]),
  ]);

  const logos = new Set(
    [...locales].map(
      (locale) =>
        og.logo ??
        resolveBrand(config.brand, locale, config.i18n).logo.logotype.onDark,
    ),
  );

  for (const logo of logos) {
    if (
      typeof logo !== "string" ||
      !/\.svg$/iu.test(logo) ||
      /^https?:\/\//iu.test(logo)
    )
      continue;
    const file = references.find(
      ({ value, file }) => value === logo && file !== null,
    )?.file;
    if (!file) continue;
    try {
      assets.logos[logo] = await readFile(file, "utf8");
    } catch (error) {
      warnings.push(
        `Cannot load OG logo ${file}: ${(error as Error).message}. Using the default mark.`,
      );
    }
  }

  return { assets, warnings };
};
